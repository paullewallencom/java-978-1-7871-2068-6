package com.sample.framework.odt;

public class ODTTestSuite extends ODTContainerRunner<ODTTestCase> {

    public ODTTestSuite() {
        this.steps = new ODTTestCase[] {};
    }
}
