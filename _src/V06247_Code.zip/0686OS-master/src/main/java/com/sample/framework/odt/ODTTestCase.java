package com.sample.framework.odt;

public class ODTTestCase extends ODTContainerRunner<ODTTestStep> {
    
    public ODTTestCase() {
        this.steps = new ODTTestStep[] {};
    }
}
